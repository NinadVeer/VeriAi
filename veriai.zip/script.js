const SUPABASE_URL = 'https://mrtcidvumccinplwwcsf.supabase.co/rest/v1/';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1ydGNpZHZ1bWNjaW5wbHd3Y3NmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzcwMzE2MTEsImV4cCI6MjA5MjYwNzYxMX0.Q8UAF7GyaKYAzsEKc4WRyd_8pg1vaA6QKa-q8o5B7PQ';
const FRAME_COUNT = 10;

// AI detection threshold:  >= AI_THRESHOLD → "Likely AI"
// Ambiguous band:           >= AMB_THRESHOLD && < AI_THRESHOLD
const AI_THRESHOLD  = 0.55;
const AMB_THRESHOLD = 0.40;

// Video signal weights (higher = more influence on final score)
const VIDEO_WEIGHTS = {
  frameConsistency:  2.0,   // Unnaturally stable frames → AI
  edgeArtifacts:     1.5,   // Blurring / compression at edges
  colorUniformity:   1.2,   // Flat, over-smooth colour palettes
  flickerVariance:   1.5,   // Low flicker = AI upscaled
  saturationScore:   1.0,   // Hyper-saturation common in AI video
  noisePattern:      1.0,   // AI video has less natural grain
};


/* ──────────────────────────────────────────────────────────────
   2. DOM REFERENCES
   ────────────────────────────────────────────────────────────── */

const resultArea     = document.getElementById('resultArea');

// Text mode
const textarea       = document.getElementById('inputText');
const wordCountEl    = document.getElementById('wordCount');
const charCountEl    = document.getElementById('charCount');
const analyzeTextBtn = document.getElementById('analyzeTextBtn');
const clearTextBtn   = document.getElementById('clearTextBtn');

// Video mode
const dropZone       = document.getElementById('dropZone');
const videoInput     = document.getElementById('videoInput');
const videoEl        = document.getElementById('videoEl');
const videoPreview   = document.getElementById('videoPreview');
const videoMeta      = document.getElementById('videoMeta');
const videoActions   = document.getElementById('videoActions');
const analyzeVideoBtn= document.getElementById('analyzeVideoBtn');
const clearVideoBtn  = document.getElementById('clearVideoBtn');
const frameCanvas    = document.getElementById('frameCanvas');
const frameStrip     = document.getElementById('frameStrip');

// Tabs
const tabText        = document.getElementById('tabText');
const tabVideo       = document.getElementById('tabVideo');
const panelText      = document.getElementById('panelText');
const panelVideo     = document.getElementById('panelVideo');
const tabImage  = document.getElementById('tabImage');
const panelImage = document.getElementById('panelImage');
// Image mode
const imgDropZone    = document.getElementById('imgDropZone');
const imageInput     = document.getElementById('imageInput');
const imgEl          = document.getElementById('imgEl');
const imgPreview     = document.getElementById('imgPreview');
const imgMeta        = document.getElementById('imgMeta');
const imgActions     = document.getElementById('imgActions');
const analyzeImageBtn= document.getElementById('analyzeImageBtn');
const clearImageBtn  = document.getElementById('clearImageBtn');
const imgCanvas      = document.getElementById('imgCanvas');



/* ──────────────────────────────────────────────────────────────
   3. TAB SWITCHING
   ✏️  EDIT HERE to add more tabs (e.g. Image Analysis).
       1. Add a new <button class="tab-btn"> in index.html
       2. Add a matching <div class="panel hidden"> in index.html
       3. Add an entry in the `tabs` array below
   ────────────────────────────────────────────────────────────── */

const tabs = [
  { btn: tabText,  panel: panelText  },
  { btn: tabVideo, panel: panelVideo },
  { btn: tabImage, panel: panelImage },
];

tabs.forEach(({ btn, panel }) => {
  btn.addEventListener('click', () => {
    tabs.forEach(t => { t.btn.classList.remove('active'); t.panel.classList.add('hidden'); });
    btn.classList.add('active');
    panel.classList.remove('hidden');
    resultArea.innerHTML = '';
  });
});


/* ══════════════════════════════════════════════════════════════
   4. TEXT MODE – EVENT LISTENERS
   ══════════════════════════════════════════════════════════════ */

textarea.addEventListener('input', updateCounts);
analyzeTextBtn.addEventListener('click', analyzeTextMode);
clearTextBtn.addEventListener('click', clearText);

document.querySelectorAll('.sample-pill').forEach(pill => {
  pill.addEventListener('click', () => {
    textarea.value = TEXT_SAMPLES[+pill.dataset.idx];
    updateCounts();
    textarea.focus();
  });
});

textarea.addEventListener('keydown', e => {
  if (e.ctrlKey && e.key === 'Enter') analyzeTextMode();
});

function updateCounts() {
  const text  = textarea.value.trim();
  const words = text ? text.split(/\s+/).filter(Boolean).length : 0;
  wordCountEl.textContent = words;
  charCountEl.textContent = textarea.value.length;
}

function clearText() {
  textarea.value = '';
  updateCounts();
  resultArea.innerHTML = '';
}

/* Sample texts */
const TEXT_SAMPLES = [
  // Human
  `Yesterday I found myself standing in my grandmother's kitchen, watching her hands move through flour and water like they'd done a thousand times before. There was something honest about the way she worked—no recipe card, no measuring cups, just muscle memory and instinct. I kept trying to write it all down, but she'd laugh and say "you can't learn bread from paper."`,
  // AI
  `In conclusion, it is important to note that artificial intelligence has the potential to significantly transform various industries and sectors. The implementation of advanced machine learning algorithms enables organizations to streamline their operational processes and enhance overall efficiency. Furthermore, it is worth mentioning that these technological advancements present both opportunities and challenges that stakeholders must carefully consider.`,
  // Mixed
  `Climate change is one of the most pressing issues of our time. The data clearly shows that global temperatures have risen by approximately 1.1 degrees Celsius since pre-industrial times. Scientists warn that we must act decisively—but honestly, it's hard not to feel a kind of helplessness when you look at the scale of what needs to change.`,
];


/* ══════════════════════════════════════════════════════════════
   5. TEXT MODE – ANALYSIS ENGINE
   ✏️  EDIT HERE to add / remove linguistic signals or
       change the weight of existing ones.
   ══════════════════════════════════════════════════════════════ */

function analyzeText(text) {
  const sentences  = text.match(/[^.!?]+[.!?]+/g) || [text];
  const words      = text.toLowerCase().match(/\b[a-z']+\b/g) || [];
  const wordCount  = words.length;
  if (wordCount < 10) return null;

  // 1. Lexical diversity
  const unique = new Set(words).size;
  const lexDiv = unique / wordCount;

  // 2. Sentence burstiness
  const sentLens   = sentences.map(s => s.split(/\s+/).filter(Boolean).length);
  const avgLen     = sentLens.reduce((a, b) => a + b, 0) / sentLens.length;
  const variance   = sentLens.reduce((a, b) => a + (b - avgLen) ** 2, 0) / sentLens.length;
  const burstiness = Math.sqrt(variance);

  // 3. AI filler phrases
  const AI_PHRASES = [
    'it is important to note','in conclusion','furthermore','moreover',
    'it is worth mentioning','it is essential',"in today's world",
    'plays a crucial role','significantly','streamline','operational',
    'delve into','nuanced','multifaceted','at the end of the day',
    'having said that','needless to say','as previously mentioned',
    'in the realm of','it goes without saying','overall','in summary',
    'to summarize','as a result','consequently','nevertheless','thus',
  ];
  const lowerText   = text.toLowerCase();
  const phraseHits  = AI_PHRASES.filter(p => lowerText.includes(p)).length;
  const phraseScore = Math.min(phraseHits / 5, 1);

  // 4. Passive voice
  const passiveMatches = (text.match(/\b(is|are|was|were|be|been|being)\s+\w+ed\b/gi) || []).length;
  const passiveRatio   = passiveMatches / Math.max(sentences.length, 1);

  // 5. First-person pronouns
  const personalPronouns = (text.match(/\b(i|i'm|i've|i'd|i'll|my|me|myself|we|our|we've)\b/gi) || []).length;
  const pronounRatio     = personalPronouns / wordCount;

  // 6. Contractions
  const contractions     = (text.match(/\b\w+'(t|re|ve|ll|d|s|m)\b/gi) || []).length;
  const contractionRatio = contractions / wordCount;

  // 7. Hedging language
  const HEDGES    = ['maybe','perhaps','i think','i feel','i guess','sort of','kind of','pretty much','seems like','honestly'];
  const hedgeHits = HEDGES.filter(h => lowerText.includes(h)).length;

  // 8. Formal transitions
  const FORMAL = ['additionally','subsequently','nevertheless','notwithstanding','henceforth','aforementioned','wherein','hereby'];
  const formalHits = FORMAL.filter(f => lowerText.includes(f)).length;

  // Scores: 0 = human, 1 = AI
  const scores = {
    lexicalDiversity:  1 - Math.min(lexDiv * 2.5, 1),
    burstiness:        1 - Math.min(burstiness / 8, 1),
    aiPhrases:         phraseScore,
    passiveVoice:      Math.min(passiveRatio * 1.5, 1),
    personalPronouns:  1 - Math.min(pronounRatio * 15, 1),
    contractions:      1 - Math.min(contractionRatio * 20, 1),
    hedging:           1 - Math.min(hedgeHits * 0.25, 1),
    formalTransitions: Math.min(formalHits * 0.25, 1),
  };

  const TEXT_WEIGHTS = {
    lexicalDiversity:1, burstiness:1.5, aiPhrases:2, passiveVoice:0.8,
    personalPronouns:1.2, contractions:1, hedging:0.7, formalTransitions:1,
  };

  let wSum = 0, wTotal = 0;
  for (const k in scores) { wSum += scores[k] * TEXT_WEIGHTS[k]; wTotal += TEXT_WEIGHTS[k]; }

  return {
    aiScore: wSum / wTotal,
    scores,
    wordCount,
    sentCount: sentences.length,
    avgSentLen: Math.round(avgLen),
  };
}

function analyzeTextMode() {
  const text = textarea.value.trim();
  if (!text || text.split(/\s+/).filter(Boolean).length < 10) {
    showError('Please enter at least 10 words to analyse.');
    return;
  }
  showLoading('Scanning linguistic patterns…');
  analyzeTextBtn.disabled = true;

  setTimeout(() => {
    const result = analyzeText(text);
    analyzeTextBtn.disabled = false;
    if (!result) { showError('Could not analyse the text.'); return; }

    const signalData = [
      { name: 'Lexical Diversity',   raw: result.scores.lexicalDiversity },
      { name: 'Sentence Burstiness', raw: result.scores.burstiness },
      { name: 'AI Phrase Density',   raw: result.scores.aiPhrases },
      { name: 'Passive Voice',       raw: result.scores.passiveVoice },
      { name: '1st-Person Pronouns', raw: result.scores.personalPronouns },
      { name: 'Contractions',        raw: result.scores.contractions },
      { name: 'Hedging Language',    raw: result.scores.hedging },
      { name: 'Formal Transitions',  raw: result.scores.formalTransitions },
    ];

    showResult({
      aiScore: result.aiScore,
      signalData,
      statsHTML: `<span>📝 ${result.wordCount} words</span>
                  <span>💬 ${result.sentCount} sentences</span>
                  <span>📏 ~${result.avgSentLen} words/sent</span>`,
      noteText: 'Results are based on heuristic linguistic patterns, not a trained ML model. Treat the output as indicative.',
    });
  }, 1200);
}


/* ══════════════════════════════════════════════════════════════
   7. VIDEO MODE – FILE HANDLING & DROP ZONE
   ✏️  EDIT accepted MIME types in index.html (accept="video/*")
       and the file-size guard below (200 MB default).
   ══════════════════════════════════════════════════════════════ */

const MAX_FILE_MB = 200;

// Click-to-browse
dropZone.addEventListener('click', () => videoInput.click());
videoInput.addEventListener('change', e => {
  if (e.target.files[0]) loadVideoFile(e.target.files[0]);
});

// Drag & drop
dropZone.addEventListener('dragover', e => { e.preventDefault(); dropZone.classList.add('drag-over'); });
dropZone.addEventListener('dragleave', () => dropZone.classList.remove('drag-over'));
dropZone.addEventListener('drop', e => {
  e.preventDefault();
  dropZone.classList.remove('drag-over');
  const file = e.dataTransfer.files[0];
  if (file && file.type.startsWith('video/')) loadVideoFile(file);
  else showError('Please drop a valid video file (MP4, WebM, MOV).');
});

function loadVideoFile(file) {
  if (file.size > MAX_FILE_MB * 1024 * 1024) {
    showError(`File too large. Maximum size is ${MAX_FILE_MB} MB.`);
    return;
  }

  const url = URL.createObjectURL(file);
  videoEl.src = url;

  videoEl.onloadedmetadata = () => {
    const dur = videoEl.duration;
    const mins = Math.floor(dur / 60);
    const secs = Math.floor(dur % 60).toString().padStart(2, '0');
    const mbSize = (file.size / (1024 * 1024)).toFixed(1);

    videoMeta.innerHTML =
      `<span>⏱ ${mins}:${secs}</span>` +
      `<span>📐 ${videoEl.videoWidth}×${videoEl.videoHeight}</span>` +
      `<span>💾 ${mbSize} MB</span>` +
      `<span>🎞 ${file.type.split('/')[1].toUpperCase()}</span>`;

    dropZone.classList.add('hidden');
    videoPreview.classList.remove('hidden');
    videoActions.classList.remove('hidden');
    frameStrip.classList.add('hidden');
    frameStrip.innerHTML = '';
    resultArea.innerHTML = '';
  };
}

// Clear video
clearVideoBtn.addEventListener('click', () => {
  videoEl.src = '';
  videoInput.value = '';
  videoPreview.classList.add('hidden');
  videoActions.classList.add('hidden');
  dropZone.classList.remove('hidden');
  frameStrip.classList.add('hidden');
  frameStrip.innerHTML = '';
  resultArea.innerHTML = '';
});

// Analyse button
analyzeVideoBtn.addEventListener('click', analyzeVideoMode);
/* ══════════════════════════════════════════════════════════════
   IMAGE MODE – FILE HANDLING & DROP ZONE
   ══════════════════════════════════════════════════════════════ */

imgDropZone.addEventListener('click', () => imageInput.click());
imageInput.addEventListener('change', e => {
  if (e.target.files[0]) loadImageFile(e.target.files[0]);
});
imgDropZone.addEventListener('dragover', e => { e.preventDefault(); imgDropZone.classList.add('drag-over'); });
imgDropZone.addEventListener('dragleave', () => imgDropZone.classList.remove('drag-over'));
imgDropZone.addEventListener('drop', e => {
  e.preventDefault();
  imgDropZone.classList.remove('drag-over');
  const file = e.dataTransfer.files[0];
  if (file && file.type.startsWith('image/')) loadImageFile(file);
  else showError('Please drop a valid image file (JPG, PNG, WebP).');
});

function loadImageFile(file) {
  if (file.size > 20 * 1024 * 1024) { showError('File too large. Max 20 MB.'); return; }
  const url = URL.createObjectURL(file);
  imgEl.src = url;
  imgEl.onload = () => {
    imgMeta.innerHTML =
      `<span>📐 ${imgEl.naturalWidth}×${imgEl.naturalHeight}</span>` +
      `<span>💾 ${(file.size/1024/1024).toFixed(2)} MB</span>` +
      `<span>🖼️ ${file.type.split('/')[1].toUpperCase()}</span>`;
    imgDropZone.classList.add('hidden');
    imgPreview.classList.remove('hidden');
    imgActions.classList.remove('hidden');
    resultArea.innerHTML = '';
  };
}

clearImageBtn.addEventListener('click', () => {
  imgEl.src = '';
  imageInput.value = '';
  imgPreview.classList.add('hidden');
  imgActions.classList.add('hidden');
  imgDropZone.classList.remove('hidden');
  resultArea.innerHTML = '';
});

analyzeImageBtn.addEventListener('click', analyzeImageMode);

/* ══════════════════════════════════════════════════════════════
   IMAGE MODE – ANALYSIS ENGINE
   Signals: edge smoothness, colour uniformity, noise/grain,
   symmetry bias, saturation, and compression artifacts.
   ══════════════════════════════════════════════════════════════ */

const IMAGE_WEIGHTS = {
  edgeSmoothness:   1.8,   // AI images have unnaturally smooth edges
  colorUniformity:  1.4,   // Flat colour zones common in diffusion models
  noiseAbsence:     1.5,   // AI lacks natural sensor grain
  saturationLevel:  1.0,   // AI often over-saturates
  symmetryBias:     1.2,   // AI tends to produce symmetric compositions
  compressionClean: 0.8,   // AI images often have fewer JPEG artifacts
};

function analyzeImageMode() {
  if (!imgEl.src || !imgEl.naturalWidth) {
    showError('Please load an image first.');
    return;
  }
  showLoading('Scanning image patterns…');
  analyzeImageBtn.disabled = true;

  setTimeout(() => {
    const w = Math.min(imgEl.naturalWidth, 640);
    const h = Math.min(imgEl.naturalHeight, 480);
    imgCanvas.width = w;
    imgCanvas.height = h;
    const ctx = imgCanvas.getContext('2d');
    ctx.drawImage(imgEl, 0, 0, w, h);
    const imageData = ctx.getImageData(0, 0, w, h);

    const result = analyzeImage(imageData, w, h);
    analyzeImageBtn.disabled = false;

    const signalData = [
      { name: 'Edge Smoothness',    raw: result.scores.edgeSmoothness },
      { name: 'Colour Uniformity',  raw: result.scores.colorUniformity },
      { name: 'Noise Absence',      raw: result.scores.noiseAbsence },
      { name: 'Saturation Level',   raw: result.scores.saturationLevel },
      { name: 'Symmetry Bias',      raw: result.scores.symmetryBias },
      { name: 'Compression Clean',  raw: result.scores.compressionClean },
    ];

    showResult({
      aiScore: result.aiScore,
      signalData,
      statsHTML: `<span>📐 ${imgEl.naturalWidth}×${imgEl.naturalHeight}</span>
                  <span>🎨 ${result.uniqueColors.toLocaleString()} sampled colors</span>
                  <span>✂️ ${result.edgeDensity}% edge density</span>`,
      noteText: 'Image analysis uses pixel-level heuristics. It works best on photorealistic AI images (Midjourney, DALL-E, Stable Diffusion). Illustrations or heavily-edited photos may produce inaccurate results.',
    });
  }, 800);
}

function analyzeImage(imageData, w, h) {
  const data = imageData.data;
  const total = w * h;

  // --- Raw pixel stats ---
  let rSum=0, gSum=0, bSum=0, rSq=0, gSq=0, bSq=0, satSum=0, edgeCount=0;
  const colorSet = new Set();

  for (let i = 0; i < total; i++) {
    const r=data[i*4], g=data[i*4+1], b=data[i*4+2];
    rSum+=r; gSum+=g; bSum+=b;
    rSq+=r*r; gSq+=g*g; bSq+=b*b;
    // Quantise to 32-step buckets for unique colour count
    colorSet.add(((r>>3)<<10)|((g>>3)<<5)|(b>>3));
    // Saturation
    const rn=r/255, gn=g/255, bn=b/255;
    const mx=Math.max(rn,gn,bn), mn=Math.min(rn,gn,bn);
    const l=(mx+mn)/2;
    satSum += mx===mn ? 0 : (mx-mn)/(1-Math.abs(2*l-1));
  }

  // Edge detection (Sobel on luminance)
  for (let y=1; y<h-1; y++) {
    for (let x=1; x<w-1; x++) {
      const idx=(y*w+x)*4;
      const lum=(data[idx]+data[idx+1]+data[idx+2])/3;
      const r2=(data[idx+4]+data[idx+5]+data[idx+6])/3;
      const d2=(data[((y+1)*w+x)*4]+data[((y+1)*w+x)*4+1]+data[((y+1)*w+x)*4+2])/3;
      if (Math.sqrt((lum-r2)**2+(lum-d2)**2) > 18) edgeCount++;
    }
  }

  const rMean=rSum/total, gMean=gSum/total, bMean=bSum/total;
  const rStd=Math.sqrt(rSq/total-rMean**2);
  const gStd=Math.sqrt(gSq/total-gMean**2);
  const bStd=Math.sqrt(bSq/total-bMean**2);
  const colorStd=(rStd+gStd+bStd)/3;
  const edgeRatio=edgeCount/total;
  const avgSat=satSum/total;

  // --- Symmetry bias (compare left half vs right half brightness) ---
  let leftLum=0, rightLum=0;
  const halfW=Math.floor(w/2);
  for (let y=0; y<h; y++) {
    for (let x=0; x<halfW; x++) {
      const l=(y*w+x)*4, r=(y*w+(w-1-x))*4;
      leftLum  += (data[l]+data[l+1]+data[l+2])/3;
      rightLum += (data[r]+data[r+1]+data[r+2])/3;
    }
  }
  const symRatio = 1 - Math.abs(leftLum-rightLum)/(leftLum+rightLum+1);

  // --- Compute signal scores (0=human, 1=AI) ---
  const scores = {
    edgeSmoothness:   1 - Math.min(edgeRatio * 20, 1),   // fewer edges → AI
    colorUniformity:  1 - Math.min(colorStd / 55, 1),    // flat colour → AI
    noiseAbsence:     colorStd < 28 ? 1 : Math.max(0, 1 - (colorStd-28)/40), // too clean → AI
    saturationLevel:  Math.min(avgSat * 1.9, 1),          // over-saturated → AI
    symmetryBias:     Math.min(symRatio * 1.2, 1),        // high symmetry → AI
    compressionClean: 1 - Math.min(edgeRatio * 30, 1),   // clean compression → AI
  };

  let wSum=0, wTotal=0;
  for (const k in scores) { wSum+=scores[k]*IMAGE_WEIGHTS[k]; wTotal+=IMAGE_WEIGHTS[k]; }

  return {
    aiScore: wSum/wTotal,
    scores,
    uniqueColors: colorSet.size,
    edgeDensity: Math.round(edgeRatio*100),
  };
}


/* ══════════════════════════════════════════════════════════════
   8. VIDEO MODE – FRAME EXTRACTION
   ✏️  Change FRAME_COUNT (top of file) to sample more/fewer frames.
       Each frame is drawn onto a hidden <canvas> for pixel analysis.
   ══════════════════════════════════════════════════════════════ */

/**
 * Seeks video to `time` seconds and resolves with ImageData.
 */
function captureFrame(video, time) {
  return new Promise((resolve, reject) => {
    const onSeeked = () => {
      video.removeEventListener('seeked', onSeeked);
      const w = Math.min(video.videoWidth,  640);
      const h = Math.min(video.videoHeight, 360);
      frameCanvas.width  = w;
      frameCanvas.height = h;
      const ctx = frameCanvas.getContext('2d');
      ctx.drawImage(video, 0, 0, w, h);
      resolve({
        imageData: ctx.getImageData(0, 0, w, h),
        dataURL:   frameCanvas.toDataURL('image/jpeg', 0.7),
        time,
      });
    };
    video.addEventListener('seeked', onSeeked);
    video.currentTime = time;
    setTimeout(() => { video.removeEventListener('seeked', onSeeked); reject(new Error('seek timeout')); }, 5000);
  });
}

/**
 * Extracts FRAME_COUNT evenly-spaced frames from the video.
 * Updates a progress bar while running.
 */
async function extractFrames(video, onProgress) {
  const duration = video.duration;
  // avoid first/last 2 s to skip blank frames
  const start  = Math.min(2, duration * 0.05);
  const end    = Math.max(duration - 2, duration * 0.95);
  const step   = (end - start) / (FRAME_COUNT - 1);
  const frames = [];

  for (let i = 0; i < FRAME_COUNT; i++) {
    const t = start + step * i;
    const frame = await captureFrame(video, t);
    frames.push(frame);
    onProgress(Math.round(((i + 1) / FRAME_COUNT) * 100));
  }
  return frames;
}


/* ══════════════════════════════════════════════════════════════
   9. VIDEO MODE – VISUAL ANALYSIS ENGINE
   ✏️  EDIT signal formulas or VIDEO_WEIGHTS (top of file)
       to tune detection for different AI video generators.
   ══════════════════════════════════════════════════════════════ */

/**
 * Returns per-pixel stats from an ImageData object.
 */
function frameStats(imageData) {
  const data = imageData.data;
  const total = data.length / 4;
  let rSum=0, gSum=0, bSum=0, rSq=0, gSq=0, bSq=0;
  let edgeCount = 0;
  const w = imageData.width;
  const h = imageData.height;

  for (let i = 0; i < total; i++) {
    const r = data[i*4], g = data[i*4+1], b = data[i*4+2];
    rSum += r; gSum += g; bSum += b;
    rSq  += r*r; gSq  += g*g; bSq  += b*b;
  }

  // Edge detection (simplified Sobel on luminance row)
  for (let y = 1; y < h-1; y++) {
    for (let x = 1; x < w-1; x++) {
      const idx = (y*w+x)*4;
      const lum = (data[idx]+data[idx+1]+data[idx+2])/3;
      const right= (data[idx+4]+data[idx+5]+data[idx+6])/3;
      const down = (data[((y+1)*w+x)*4]+data[((y+1)*w+x)*4+1]+data[((y+1)*w+x)*4+2])/3;
      const gx = Math.abs(lum - right);
      const gy = Math.abs(lum - down);
      if (Math.sqrt(gx*gx+gy*gy) > 20) edgeCount++;
    }
  }

  const rMean = rSum/total, gMean = gSum/total, bMean = bSum/total;
  const rStd  = Math.sqrt(rSq/total - rMean**2);
  const gStd  = Math.sqrt(gSq/total - gMean**2);
  const bStd  = Math.sqrt(bSq/total - bMean**2);
  const edgeRatio = edgeCount / total;

  // Saturation (HSL)
  let satSum = 0;
  for (let i = 0; i < total; i++) {
    const r=data[i*4]/255, g=data[i*4+1]/255, b=data[i*4+2]/255;
    const max=Math.max(r,g,b), min=Math.min(r,g,b);
    const l=(max+min)/2;
    satSum += max===min ? 0 : (max-min)/(1-Math.abs(2*l-1));
  }

  return {
    rMean, gMean, bMean,
    rStd, gStd, bStd,
    colorStd: (rStd+gStd+bStd)/3,
    edgeRatio,
    avgSat: satSum / total,
  };
}

/**
 * Analyses an array of frame stats and returns a video result object.
 * Scores: 0 = human, 1 = AI
 */
function analyzeFrames(stats) {
  const n = stats.length;

  // 1. Frame-to-frame colour consistency (low variance → AI)
  const means = stats.map(s => (s.rMean + s.gMean + s.bMean) / 3);
  const meanAvg = means.reduce((a,b)=>a+b,0)/n;
  const meanVar = means.reduce((a,b)=>a+(b-meanAvg)**2,0)/n;
  const frameConsistency = 1 - Math.min(Math.sqrt(meanVar) / 15, 1); // 0=varied,1=flat

  // 2. Edge artifact score (blurry edges common in AI video)
  const edgeRatios = stats.map(s => s.edgeRatio);
  const avgEdge    = edgeRatios.reduce((a,b)=>a+b,0)/n;
  const edgeArtifacts = 1 - Math.min(avgEdge * 25, 1); // low edges → AI

  // 3. Colour uniformity (flat colour distribution → AI)
  const stdVals = stats.map(s => s.colorStd);
  const avgStd  = stdVals.reduce((a,b)=>a+b,0)/n;
  const colorUniformity = 1 - Math.min(avgStd / 60, 1);

  // 4. Flicker variance (AI = smooth/no flicker)
  const diffs = [];
  for (let i=1; i<n; i++) diffs.push(Math.abs(means[i]-means[i-1]));
  const flickerMean = diffs.reduce((a,b)=>a+b,0)/Math.max(diffs.length,1);
  const flickerVariance = 1 - Math.min(flickerMean / 5, 1);

  // 5. Saturation score (AI often over-saturates)
  const avgSat = stats.map(s => s.avgSat).reduce((a,b)=>a+b,0)/n;
  const saturationScore = Math.min(avgSat * 1.8, 1);

  // 6. Noise / grain pattern (human video has more sensor noise)
  const noiseProxy = stats.map(s => s.colorStd).reduce((a,b)=>a+(b<30?1:0),0)/n;
  const noisePattern = noiseProxy; // fraction of "too smooth" frames

  const scores = { frameConsistency, edgeArtifacts, colorUniformity, flickerVariance, saturationScore, noisePattern };

  let wSum=0, wTotal=0;
  for (const k in scores) { wSum += scores[k] * VIDEO_WEIGHTS[k]; wTotal += VIDEO_WEIGHTS[k]; }

  // Per-frame anomaly flags for the thumbnail strip
  const frameFlags = stats.map(s => {
    const localFlat = s.colorStd < 25;
    const localBlur = s.edgeRatio < 0.02;
    return localFlat || localBlur; // true = flagged as suspicious
  });

  return { aiScore: wSum / wTotal, scores, frameFlags };
}


/* ══════════════════════════════════════════════════════════════
   10. VIDEO MODE – UI RENDERING
   ══════════════════════════════════════════════════════════════ */

async function analyzeVideoMode() {
  if (!videoEl.src || !videoEl.duration) {
    showError('Please load a video file first.');
    return;
  }

  analyzeVideoBtn.disabled = true;
  frameStrip.classList.add('hidden');
  frameStrip.innerHTML = '';

  // Show progress UI inside resultArea
  resultArea.innerHTML = `
    <div class="loading-state" id="videoProgress">
      <div class="spinner"></div>
      <div class="loading-text" id="progressLabel">Extracting frames… 0%</div>
      <div style="width:100%;max-width:340px;">
        <div class="progress-wrap">
          <div class="progress-fill" id="progressFill"></div>
        </div>
      </div>
    </div>`;

  const progressFill  = document.getElementById('progressFill');
  const progressLabel = document.getElementById('progressLabel');

  let frames;
  try {
    frames = await extractFrames(videoEl, pct => {
      progressFill.style.width  = pct + '%';
      progressLabel.textContent = `Extracting frames… ${pct}%`;
    });
  } catch (err) {
    analyzeVideoBtn.disabled = false;
    showError('Frame extraction failed. Try a shorter or different video.');
    return;
  }

  progressLabel.textContent = 'Analysing visual patterns…';

  // Short delay so user sees the label change
  await new Promise(r => setTimeout(r, 400));

  const stats  = frames.map(f => frameStats(f.imageData));
  const result = analyzeFrames(stats);

  analyzeVideoBtn.disabled = false;

  // Render frame strip
  frameStrip.innerHTML = frames.map((f, i) => `
    <div class="frame-thumb ${result.frameFlags[i] ? 'flagged' : 'clean'}">
      <img src="${f.dataURL}" alt="Frame at ${f.time.toFixed(1)}s"/>
      <div class="frame-label">${f.time.toFixed(1)}s ${result.frameFlags[i] ? '⚠️' : '✓'}</div>
    </div>`).join('');
  frameStrip.classList.remove('hidden');

  const flagged = result.frameFlags.filter(Boolean).length;

  const signalData = [
    { name: 'Frame Consistency',  raw: result.scores.frameConsistency },
    { name: 'Edge Artifacts',     raw: result.scores.edgeArtifacts },
    { name: 'Colour Uniformity',  raw: result.scores.colorUniformity },
    { name: 'Flicker Variance',   raw: result.scores.flickerVariance },
    { name: 'Saturation Level',   raw: result.scores.saturationScore },
    { name: 'Noise / Grain',      raw: result.scores.noisePattern },
  ];

  showResult({
    aiScore: result.aiScore,
    signalData,
    statsHTML: `<span>🎞 ${frames.length} frames sampled</span>
                <span>⚠️ ${flagged} suspicious frames</span>
                <span>⏱ ${videoEl.duration.toFixed(1)}s duration</span>`,
    noteText: 'Video analysis uses pixel-level heuristics (colour, edges, flicker). It cannot detect deepfakes reliably — for that, a dedicated ML model is required.',
  });
}


/* ══════════════════════════════════════════════════════════════
   11. SHARED RESULT RENDERER
   ✏️  EDIT the verdict copy or colour palette below.
   ══════════════════════════════════════════════════════════════ */

function showResult({ aiScore, signalData, statsHTML, noteText }) {
  const pct     = Math.round(aiScore * 100);
  const isAI    = pct >= AI_THRESHOLD  * 100;
  const isAmb   = pct >= AMB_THRESHOLD * 100 && !isAI;

  const color = isAmb ? '#f59e0b' : isAI ? 'var(--ai)' : 'var(--human)';
  const bgCol = isAmb ? 'rgba(245,158,11,0.08)'
              : isAI  ? 'rgba(248,113,113,0.08)'
                      : 'rgba(74,222,128,0.08)';
  const icon  = isAmb ? '🤔' : isAI ? '🤖' : '👤';
  const label = isAmb ? 'Ambiguous'
              : isAI  ? 'Likely AI-Generated'
                      : 'Likely Human-Made';
  const sub   = isAmb ? 'The signals are mixed — could be either.'
              : isAI  ? `${pct}% probability this content was AI-generated.`
                      : `${100-pct}% probability this content was made by a human.`;

  const chipsHTML = signalData.map(s => `
    <div class="signal-chip">
      <div class="signal-dot" style="background:${sigColor(s.raw)}"></div>
      <div>
        <div class="signal-name">${s.name}</div>
        <div class="signal-val" style="color:${sigColor(s.raw)}">${fmtSig(s.raw)}</div>
      </div>
    </div>`).join('');

  resultArea.innerHTML = `
    <div id="result" style="background:${bgCol}; border:1px solid ${color}22;">
      <div class="result-header">
        <div class="verdict-badge">
          <div class="verdict-icon" style="background:${color}22">${icon}</div>
          <div>
            <div class="verdict-label" style="color:${color}">${label}</div>
            <div class="verdict-sub">${sub}</div>
          </div>
        </div>
      </div>

      <div class="result-body">
        <div class="confidence-section">
          <div class="conf-labels"><span>Human</span><span>AI</span></div>
          <div class="conf-track">
            <div class="conf-fill" id="confFill" style="background:${color}; width:0%"></div>
          </div>
          <div class="conf-pct" style="color:${color}">${pct}% AI probability</div>
        </div>

        <div class="divider"></div>
        <div class="signals-title">Signal Breakdown</div>
        <div class="signals-grid">${chipsHTML}</div>
        <div class="divider"></div>

        <div class="stats-row">${statsHTML}</div>
        <div class="divider"></div>

        <div class="note">
          <span class="note-icon">💡</span>
          <span>${noteText}</span>
        </div>
      </div>
    </div>`;

  requestAnimationFrame(() => {
    setTimeout(() => { document.getElementById('confFill').style.width = pct + '%'; }, 50);
  });

  document.getElementById('result').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function showLoading(msg = 'Analysing…') {
  resultArea.innerHTML = `
    <div class="loading-state">
      <div class="spinner"></div>
      <div class="loading-text">${msg}</div>
    </div>`;
}

function showError(msg) {
  resultArea.innerHTML = `
    <div class="loading-state">
      <div style="font-size:28px">⚠️</div>
      <div class="loading-text">${msg}</div>
    </div>`;
}


/* ══════════════════════════════════════════════════════════════
   12. HELPERS
   ══════════════════════════════════════════════════════════════ */

function fmtSig(val) {
  if (val < 0.3)  return 'Human signal';
  if (val < 0.55) return 'Neutral';
  if (val < 0.8)  return 'AI signal';
  return 'Strong AI signal';
}

function sigColor(val) {
  if (val < 0.3)  return 'var(--human)';
  if (val < 0.55) return '#94a3b8';
  if (val < 0.8)  return '#f59e0b';
  return 'var(--ai)';
}

// ── Supabase Setup ──
const SUPABASE_URL = 'https://YOUR_PROJECT_URL.supabase.co';
const SUPABASE_KEY = 'YOUR_ANON_KEY';
const { createClient } = window.supabase;
const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

// Store analysis result in Supabase
async function saveAnalysisResult(userId, contentType, confidenceScore, verdict, details) {
  try {
    const { data, error } = await supabase
      .from('analysis_results')
      .insert([
        {
          user_id: userId,
          content_type: contentType,
          confidence_score: confidenceScore,
          verdict: verdict,
          details: details
        }
      ]);
    
    if (error) console.error('Error saving result:', error);
    else console.log('Result saved:', data);
  } catch (err) {
    console.error('Supabase error:', err);
  }
}

// Get user's analysis history
async function getUserHistory(userId) {
  try {
    const { data, error } = await supabase
      .from('analysis_results')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });
    
    if (error) console.error('Error fetching history:', error);
    else return data;
  } catch (err) {
    console.error('Supabase error:', err);
  }
}

// After you get analysis results, add:
async function displayResult(contentType, confidenceScore, verdict, fullAnalysis) {
  // ... your existing result display code ...
  
  // Get current Firebase user
  const user = auth.currentUser;
  if (user) {
    // Get Supabase user ID from Firebase ID
    const { data: userData } = await supabase
      .from('users')
      .select('id')
      .eq('firebase_id', user.uid)
      .single();
    
    if (userData) {
      await saveAnalysisResult(
        userData.id,
        contentType,
        confidenceScore,
        verdict,
        fullAnalysis
      );
    }
  }
}